#include "DXUT.h"
#include "Header.h"


CGameScene::CGameScene()
{
}


CGameScene::~CGameScene()
{
}

void CGameScene::Update(float deltaTime)
{
}

void CGameScene::Render(LPD3DXSPRITE sprite)
{
}

void CGameScene::MsgProc(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
}
