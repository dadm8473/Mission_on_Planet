#include "DXUT.h"
#include "Header.h"


CScene::CScene()
{
}


CScene::~CScene()
{
}

void CScene::Update(float deltaTime)
{
}

void CScene::Render(LPD3DXSPRITE sprite)
{
}

void CScene::MsgProc(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
}
